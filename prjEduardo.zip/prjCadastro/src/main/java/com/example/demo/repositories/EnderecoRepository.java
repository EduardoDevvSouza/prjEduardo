package com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.Endereco;

public interface EnderecoRepository extends JpaRepository<Endereco, Long> {


}